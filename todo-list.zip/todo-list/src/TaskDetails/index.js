import React, { useState } from "react";
import EditForm from "../EditForm";
import Modal from "../Delete";
import "./style.css";

const TaskDetails = () => {
  const [products, setProducts] = useState([
    {
      id: 1,
      assignedTo: "User 1",
      status: "Completed",
      dueDate: "2024-10-10",
      priority: "Low",
      comments: "This task is good",
    },
    {
      id: 2,
      assignedTo: "User 2",
      status: "In Progress",
      dueDate: "2024-04-09",
      priority: "High",
      comments: "This task is good",
    },
    {
      id: 3,
      assignedTo: "User 3",
      status: "Not Started",
      dueDate: "2024-08-09",
      priority: "Low",
      comments: "This task is good",
    },
    {
      id: 4,
      assignedTo: "User 4",
      status: "In Progress",
      dueDate: "2024-06-03",
      priority: "Normal",
      comments: "This task is good",
    },
  ]);

  const [showForm, setShowForm] = useState(false);
  const [editProduct, setEditProduct] = useState(null);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [productToDelete, setProductToDelete] = useState(null);

  const openForm = (product = null) => {
    setEditProduct(product);
    setShowForm(true);
  };

  const closeForm = () => {
    setShowForm(false);
    setEditProduct(null);
  };

  const saveProduct = (product) => {
    if (editProduct) {
      setProducts(products.map((p) => (p.id === product.id ? product : p)));
    } else {
      setProducts([...products, { ...product, id: products.length + 1 }]);
    }
    closeForm();
  };

  const openModal = (id) => {
    setProductToDelete(id);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setProductToDelete(null);
  };

  const deleteProduct = () => {
    setProducts(products.filter((p) => p.id !== productToDelete));
    closeModal();
  };

  return (
    <div>
      <div className="container" data-testid="person-details">
        <table className="table" data-testid="product-table">
          <thead>
            <tr className="tableHeader">
              <th className="tableCell">Assigned To</th>
              <th className="tableCell">Status</th>
              <th className="tableCell">Due Date</th>
              <th className="tableCell">Priority</th>
              <th className="tableCell">Comments</th>
              <th className="tableCell">Actions</th>
            </tr>
          </thead>
          <tbody>
            {products.map((product) => (
              <tr key={product.id} data-testid={`product-row-${product.id}`}>
                <td className="tableCell">{product.assignedTo}</td>
                <td className="tableCell">{product.status}</td>
                <td className="tableCell">{product.dueDate}</td>
                <td className="tableCell">{product.priority}</td>
                <td className="tableCell">{product.comments}</td>
                <td className="tableCell buttonWrapper">
                  <button
                    className="editButton"
                    onClick={() => openForm(product)}
                    data-testid={`edit-button-${product.id}`}
                  >
                    Edit
                  </button>
                  <button
                    className="deleteButton"
                    onClick={() => openModal(product.id)}
                    data-testid={`delete-button-${product.id}`}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <button
        className="addButton"
        onClick={() => openForm()}
        data-testid="add-button"
      >
        Add New Task
      </button>
      {showForm && (
        <EditForm
          product={editProduct}
          onSave={saveProduct}
          onClose={closeForm}
          data-testid="edit-form"
        />
      )}
      <Modal
        isOpen={isModalOpen}
        onClose={closeModal}
        onDelete={deleteProduct}
        data-testid="delete-modal"
      />
    </div>
  );
};

export default TaskDetails;