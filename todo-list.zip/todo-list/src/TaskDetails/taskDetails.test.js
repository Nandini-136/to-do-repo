

import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import "@testing-library/jest-dom";

import TaskDetails from ".";
import EditForm from "../EditForm";
import Modal from "../Delete";

jest.mock("../EditForm", () => ({ product, onSave, onClose }) => (
  <div>
    <button onClick={() => onSave({ ...product, assignedTo: "Updated User" })}>
      Save
    </button>
    <button onClick={onClose}>Close</button>
  </div>
));

jest.mock(
  "../Delete",
  () =>
    ({ isOpen, onClose, onDelete }) =>
      isOpen ? (
        <div data-testid="delete-modal">
          <button data-testid="confirm-delete-button" onClick={onDelete}>
            Delete
          </button>
          <button onClick={onClose}>Close</button>
        </div>
      ) : null
);

describe("TaskDetails Component", () => {
  test("renders the table with product data", () => {
    render(<TaskDetails />);

    // Check if the table is rendered
    const table = screen.getByTestId("product-table");
    expect(table).toBeInTheDocument();

    // Check if the products are displayed in the table
    expect(screen.getByText("Completed")).toBeInTheDocument();
    expect(screen.getByText("2024-10-10")).toBeInTheDocument();
  });

  test("opens the edit form when clicking edit button", () => {
    render(<TaskDetails />);

    // Click on the Edit button for the first product
    const editButton = screen.getByTestId("edit-button-1");
    fireEvent.click(editButton);
  });

  test("opens the delete modal when clicking delete button", () => {
    render(<TaskDetails />);

    // Click the delete button for the first product
    const deleteButton = screen.getByTestId("delete-button-1");
    fireEvent.click(deleteButton);

    // Check if the delete modal is shown
    expect(screen.getByTestId("delete-modal")).toBeInTheDocument();
  });

  test("deletes a product when clicking delete in the modal", async () => {
    render(<TaskDetails />);

    // Open the modal for deletion
    const deleteButton = screen.getByTestId("delete-button-1");
    fireEvent.click(deleteButton);

    // Click the delete button in the modal using data-testid
    const confirmDeleteButton = screen.getByTestId("confirm-delete-button");
    fireEvent.click(confirmDeleteButton);

    // Wait for the product to be removed from the table
    await waitFor(() =>
      expect(screen.queryByText("User 1")).not.toBeInTheDocument()
    );
  });

  test("does not delete when canceling in the modal", () => {
    render(<TaskDetails />);

    // Open the modal for deletion
    const deleteButton = screen.getByTestId("delete-button-1");
    fireEvent.click(deleteButton);

    // Click the close button in the modal
    const closeModalButton = screen.getByText("Close");
    fireEvent.click(closeModalButton);

    // Ensure the product is still in the table
    expect(screen.getByText("User 1")).toBeInTheDocument();
  });
});