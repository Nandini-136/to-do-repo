import React from "react";
import "./style.css";

const Modal = ({ isOpen, onClose, onDelete }) => {
  if (!isOpen) return null;

  return (
    <div className="modal-overlay">
      <div className="modal-container">
        <div className="modal-header">Delete</div>
        <div className="modal-content">
          <p>Do you really want to delete this task?</p>
        </div>
        <div className="modal-footer">
          <button className="modal-button no" onClick={onClose}>
            No
          </button>
          <button className="modal-button yes" onClick={onDelete}>
            Yes
          </button>
        </div>
      </div>
    </div>
  );
};

export default Modal;