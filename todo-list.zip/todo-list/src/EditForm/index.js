import React, { useState, useEffect } from "react";
import "./style.css";

const EditForm = ({ product, onSave, onClose }) => {
  const [formData, setFormData] = useState({
    id: null,
    assignedTo: "",
    status: "",
    dueDate: "",
    priority: "",
    comments: "",
  });

  useEffect(() => {
    if (product) {
      const formattedDate = product.dueDate
        ? product.dueDate.split("-").reverse().join("/") 
        : "";
      setFormData({
        id: product.id,
        assignedTo: product.assignedTo,
        status: product.status,
        dueDate: formattedDate,
        priority: product.priority,
        comments: product.comments,
      });
    } else {
      setFormData({
        id: null,
        assignedTo: "",
        status: "",
        dueDate: "",
        priority: "",
        comments: "",
      });
    }
  }, [product]);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const { assignedTo, status, dueDate, priority, comments, id } = formData;

    if (assignedTo && status && priority) {
      // Convert dueDate back to YYYY-MM-DD format for saving
      const formattedDueDate = dueDate
        ? dueDate.split("/").reverse().join("-") // Convert back to YYYY-MM-DD
        : "";
      onSave({ ...formData, dueDate: formattedDueDate });
    }
  };

  return (
    <div className="modal" data-testid="edit-form-modal">
      <div className="modalDialog">
        <div className="modalContent">
          <div className="modalHeader">
            <div className="modalTitle" data-testid="modal-title">
              {product ? "Edit Task" : "New Task"}
            </div>
          </div>
          <div className="modalBody">
            <form data-testid="edit-form">
              <div className="formRow">
                <div className="formGroup">
                  <label htmlFor="assignedTo">
                    <span>*</span>Assigned To
                  </label>
                  <input
                    type="text"
                    className="formInput"
                    id="assignedTo"
                    name="assignedTo"
                    value={formData.assignedTo}
                    onChange={handleChange}
                    required
                    data-testid="name-input"
                  />
                </div>
                <div className="formGroup">
                  <label htmlFor="status">
                    <span>*</span>Status
                  </label>
                  <select
                    className="formInput"
                    id="status"
                    name="status"
                    value={formData.status}
                    onChange={handleChange}
                    required
                    data-testid="status-select"
                  >
                    <option value="">Select Status</option>
                    <option value="In Progress">In Progress</option>
                    <option value="Not Started">Not Started</option>
                    <option value="Completed">Completed</option>
                  </select>
                </div>
              </div>

              <div className="formRow">
                <div className="formGroup">
                  <label htmlFor="dueDate">Due Date</label>
                  <input
                    type="date" // Use date input type for proper date handling
                    className="formInput"
                    id="dueDate"
                    name="dueDate"
                    value={formData.dueDate.split("/").reverse().join("-")} // Convert DD/MM/YYYY to YYYY-MM-DD for date input
                    onChange={handleChange}
                    data-testid="age-input"
                  />
                </div>
                <div className="formGroup">
                  <label htmlFor="priority">
                    <span>*</span>Priority
                  </label>
                  <select
                    className="formInput"
                    id="priority"
                    name="priority"
                    value={formData.priority}
                    onChange={handleChange}
                    required
                    data-testid="priority-select"
                  >
                    <option value="">Select Priority</option>
                    <option value="High">High</option>
                    <option value="Low">Low</option>
                    <option value="Normal">Normal</option>
                  </select>
                </div>
              </div>

              <div className="formGroup">
                <label htmlFor="comments">Description</label>
                <textarea
                  className="formInput"
                  id="comments"
                  name="comments"
                  value={formData.comments}
                  onChange={handleChange}
                  data-testid="comments-input"
                  rows="4"
                />
              </div>

              <div className="modal-footer">
                <button
                  type="button"
                  className="cancelButton"
                  onClick={onClose}
                  data-testid="close-btn"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="saveButton"
                  data-testid="save-btn"
                  onClick={handleSubmit}
                >
                  Save
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EditForm;