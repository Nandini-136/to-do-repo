
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import "@testing-library/jest-dom";
import EditForm from ".";

// Mock callback functions
const onSave = jest.fn();
const onClose = jest.fn();

describe("EditForm Component", () => {
  test("renders EditForm with product data", () => {
    const product = {
      id: 1,
      assignedTo: "John Doe",
      status: "Completed",
      dueDate: "2024-10-10",
      priority: "High",
      comments: "This task is important",
    };

    render(<EditForm product={product} onSave={onSave} onClose={onClose} />);

    // Ensure the input fields are populated with the correct values
    expect(screen.getByTestId("name-input")).toHaveValue("John Doe");
    expect(screen.getByTestId("status-select")).toHaveValue("Completed");
    expect(screen.getByTestId("age-input")).toHaveValue("2024-10-10");
    expect(screen.getByTestId("priority-select")).toHaveValue("High");
    expect(screen.getByTestId("comments-input")).toHaveValue(
      "This task is important"
    );
  });

  test("handles input field changes correctly", () => {
    const product = {
      id: 1,
      assignedTo: "",
      status: "",
      dueDate: "",
      priority: "",
      comments: "",
    };

    render(<EditForm product={product} onSave={onSave} onClose={onClose} />);

    const nameInput = screen.getByTestId("name-input");
    const statusSelect = screen.getByTestId("status-select");
    const dueDateInput = screen.getByTestId("age-input");
    const prioritySelect = screen.getByTestId("priority-select");
    const commentsInput = screen.getByTestId("comments-input");

    // Simulate user typing
    fireEvent.change(nameInput, { target: { value: "Jane Doe" } });
    fireEvent.change(statusSelect, { target: { value: "In Progress" } });
    fireEvent.change(dueDateInput, { target: { value: "2024-12-01" } });
    fireEvent.change(prioritySelect, { target: { value: "Normal" } });
    fireEvent.change(commentsInput, { target: { value: "New task details" } });

    // Ensure that the state updates
    expect(nameInput).toHaveValue("Jane Doe");
    expect(statusSelect).toHaveValue("In Progress");
    expect(dueDateInput).toHaveValue("2024-12-01");
    expect(prioritySelect).toHaveValue("Normal");
    expect(commentsInput).toHaveValue("New task details");
  });

  test("calls onSave when submitting the form with valid data", async () => {
    const product = {
      id: 1,
      assignedTo: "John Doe",
      status: "Completed",
      dueDate: "2024-10-10",
      priority: "High",
      comments: "Task completed",
    };

    render(<EditForm product={product} onSave={onSave} onClose={onClose} />);

    const saveButton = screen.getByTestId("save-btn");
    fireEvent.click(saveButton);

    // Wait for onSave to be called
    await waitFor(() => expect(onSave).toHaveBeenCalledTimes(1));
    expect(onSave).toHaveBeenCalledWith({
      id: 1,
      assignedTo: "John Doe",
      status: "Completed",
      dueDate: "2024-10-10",
      priority: "High",
      comments: "Task completed",
    });
  });

  test("does not call onSave when required fields are missing", async () => {
    const product = {
      id: 1,
      assignedTo: "",
      status: "",
      dueDate: "",
      priority: "",
      comments: "",
    };

    render(<EditForm product={product} onSave={onSave} onClose={onClose} />);

    const saveButton = screen.getByTestId("save-btn");
    fireEvent.click(saveButton);

    // Ensure onSave was not called
    await waitFor(() => expect(onSave).not.toHaveBeenCalled());
  });

  test("calls onClose when cancel button is clicked", () => {
    render(<EditForm product={null} onSave={onSave} onClose={onClose} />);

    const closeButton = screen.getByTestId("close-btn");
    fireEvent.click(closeButton);

    // Ensure onClose is called
    expect(onClose).toHaveBeenCalledTimes(1);
  });
});