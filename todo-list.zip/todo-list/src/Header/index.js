import React from "react";
import "./style.css"; 

const Header = () => {
  return <div className="headerContainer">Todo List App</div>;
};

export default Header;