
import React from "react";
import Header from "./Header";
import TaskDetails from "./TaskDetails";

import "./App.css";

function App() {
  return (
    <div>
      <div className="headerWrapper">
        <Header />
      </div>

      <div className="pageWrapper">
        <TaskDetails />
      </div>
    </div>
  );
}

export default App;
